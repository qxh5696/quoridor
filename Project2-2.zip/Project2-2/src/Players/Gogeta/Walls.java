package Players.Gogeta;

import Interface.Coordinate;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qadirhaqq on 4/9/15.
 */
public class Walls {
    private Coordinate start;
    private Coordinate middle;
    private Coordinate end;
    private String orientation;
    private static final String HORIZONTAL = "H";
    private static final String VERTICAL = "V";
    public Walls(Coordinate start,Coordinate end){
        this.start = start;
        this.end = end;
        if (start.getRow() == end.getRow()){
            this.middle = new Coordinate(end.getRow(), end.getCol()-1);
        }else if (start.getCol() == end.getCol()){
            this.middle = new Coordinate(end.getRow()-1 ,end.getCol());
        }
        this.orientation = setOrientation();
    }
    public Coordinate getStart(){
        return start;
    }

    public Coordinate getEnd(){
        return end;
    }

    public String toString(){
        String result = "";
        result += "Start: " + this.start + " End: " + this.end;
        return result;
    }

    public boolean equals(Object o){
        if(o instanceof Walls){
            Walls tmp = (Walls) o;
            if(this.start.equals(tmp.getStart())){
                if(this.end.equals(tmp.getEnd())){
                    if(this.middle.equals(tmp.middle)){
                        if(this.orientation.equals(tmp.orientation)){
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public Walls bisect(){
        Coordinate tempStart;
        Coordinate tempEnd;
        Walls bisect;
        if(this.orientation.equals(HORIZONTAL)){
            tempStart = new Coordinate(start.getRow()-1, start.getCol()+1);
            tempEnd = new Coordinate(end.getRow()+1, end.getCol()-1);
            bisect = new Walls(tempStart, tempEnd);
        }
        else{
            tempStart = new Coordinate(start.getRow()+1, start.getCol()-1);
            tempEnd = new Coordinate(end.getRow()-1, end.getCol()+1);
            bisect = new Walls(tempStart, tempEnd);
        }
        return bisect;
    }
    public List<Walls> surrounding(){
        List<Walls> surrroundingWalls = new ArrayList<Walls>();
        Coordinate tempStart;
        Coordinate tempEnd;
        if (this.orientation.equals(HORIZONTAL)){
            tempEnd = new Coordinate(this.middle.getRow(), this.middle.getCol()+2);
            tempStart = new Coordinate(this.middle.getRow(), this.middle.getCol()-2);

        }
        else{
            tempEnd = new Coordinate(this.middle.getRow()+2, this.middle.getCol());
            tempStart = new Coordinate(this.middle.getRow()-2, this.middle.getCol());
        }
        surrroundingWalls.add(new Walls(this.middle, tempEnd));
        surrroundingWalls.add(new Walls(tempStart ,this.middle));
        return surrroundingWalls;
    }
    /*
    public List<Walls> box(){
        List<Walls> boxWalls = new ArrayList<Walls>();
        Coordinate tempStart;
        Coordinate tempEnd;
        Walls temp;
        if(orientation.equals(VERTICAL)){//Example: start=[7,4] end=[9,4],
            if(end.getRow() == 9){
                if(end.getCol()+1 <= 9){//Add (7,3) to (7,5)//Horizontal
                    tempStart = new Coordinate(start.getRow(), start.getCol()-1);
                    tempEnd = new Coordinate(end.getRow() - 2, end.getCol()+1);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }

                if(start.getCol()-1 >= 0){//add(7,3) to (9,3)Vertical
                    tempStart = new Coordinate(start.getRow(), start.getCol()-1);
                    tempEnd = new Coordinate(end.getRow(), end.getCol()-1);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(end.getCol() +1 <= 9){//add(7,5) to (9,5)Vertical
                    tempStart = new Coordinate(start.getRow(), start.getCol()+1);
                    tempEnd = new Coordinate(end.getRow(), end.getCol()+1);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(start.getCol() - 2 >= 0){//add(7,2) to (7,4)//Horizontal
                    tempStart = new Coordinate(start.getRow(), start.getCol()-2);
                    tempEnd = new Coordinate(start.getRow(), start.getCol());
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(end.getCol()+2  <= 9){//add(7,4) to (7,6)//Horizontal
                    tempStart = new Coordinate(end.getRow(), end.getCol());
                    tempEnd = new Coordinate(end.getRow(), end.getCol()+2);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
            }
            else if(start.getRow() == 0) {//(0,4) to (2,4)
                if (start.getCol() - 1 >= 0) {//add (0,3) to (2,3)
                    tempStart = new Coordinate(start.getRow(), start.getCol() - 1);//(0,3)
                    tempEnd = new Coordinate(end.getRow(), end.getCol() - 1);//(2,3)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if (end.getCol()+1 <= 9) {//(0,5) to (2,5)
                    tempStart = new Coordinate(start.getRow(), start.getCol()+1);//(0, 5)
                    tempEnd = new Coordinate(end.getRow(), end.getCol()+1);//(2,5)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(start.getCol()-2 >= 0){//(2,2) to (2,4)
                    tempStart = new Coordinate(start.getRow()+2, start.getCol()-2);//(2,2)
                    tempEnd = new Coordinate(end.getRow(), end.getCol());//(2,4)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(start.getCol()-1 >= 0){//(2,3) to (2,5)
                    tempStart = new Coordinate(start.getRow()+2, start.getCol()-1);//(2,3)
                    tempEnd = new Coordinate(end.getRow(), end.getCol()+1);//(2,5)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                if(end.getCol()+2 >= 9){//(2,4) to (2,6)
                    tempStart = new Coordinate(end.getRow(), end.getCol());//(2,4)
                    tempEnd = new Coordinate(end.getRow(), end.getCol()+2);//(2,6)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
            }
            else{//The wall is vertical but not against the border of the board

            }
        }
        if(orientation.equals(HORIZONTAL)){
            if(end.getCol() == 9){//Horizontal wall from (4,7) to (4,9)
                //Add (3,7) to (3,9)
                if(start.getRow()-1 >= 0){
                   tempStart = new Coordinate(start.getRow()-1, start.getCol());//(3,7)
                   tempEnd = new Coordinate(end.getRow()-1, end.getCol());//(3,9)
                   boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //Add (5,7) to (5,9)
                if(end.getRow()+1 <= 9){
                    tempStart = new Coordinate(start.getRow()+1, start.getCol());//(5,7)
                    tempEnd = new Coordinate(end.getRow()+1, end.getCol());//(5,9)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //Add (2,7) to (4,7)
                if(start.getRow()-2 >= 0){
                    tempStart = new Coordinate(start.getRow()-2, start.getCol());//(2,7)
                    tempEnd = new Coordinate(start.getRow(), start.getCol());//(4,7)
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //Add (3,7) to (5,7)
                if(end.getCol()+2 <= 9 && start.getRow() >= 0){
                    tempStart = new Coordinate(start.getRow()-1, start.getCol());
                    tempEnd = new Coordinate(end.getRow()+1, end.getCol()+2);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //Add (4,7) to (6,7)
                if(end.getRow()+2 <= 9 || end.getCol() <= 9){
                    tempStart = new Coordinate(start.getRow(), start.getCol());
                    tempEnd = new Coordinate(end.getRow()+2, end.getCol()+2);
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
            }
            else if(start.getCol() == 0){//(4,0) to (4,2)
                //add(3,0) to (3,2)
                if(){

                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //add(5,0) to (5,2)
                if(){
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //add(3,2) to (5,2)
                if(){
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //add(2,2) to (4,2)
                if(){
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }
                //add(4,2) to (6,2)
                if(){
                    boxWalls.add(new Walls(tempStart, tempEnd));
                }

            }
            else{//The wall is horizontal but not against the border of the board

            }
        }
        return boxWalls;
    }*/
    private String setOrientation(){
        if (start.getCol() == end.getCol()){
            return VERTICAL;
        }
        else{
            return HORIZONTAL;
        }

    }

}
