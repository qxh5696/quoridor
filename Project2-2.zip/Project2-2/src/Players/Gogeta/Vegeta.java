package Players.Gogeta;
import Engine.Logger;
import Interface.Coordinate;
import Interface.PlayerModule;
import Interface.PlayerMove;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Created by qadirhaqq on 4/8/15.
 */
public class Vegeta implements PlayerModule{


    //Variables I Added
    private Logger logger;
    private Map<Integer, Coordinate> playerHomes = new HashMap<Integer, Coordinate>();
    private Map<Integer, Integer> playerWalls = new HashMap<Integer, Integer>();
    private int numWalls;
    private static final int MAX_ROWS = 9;
    private static final int MAX_COLUMNS = 9;
    private static final Node[][] board = new Node[MAX_ROWS][MAX_COLUMNS];
    private int playerId;
    private boolean playerMoving = true;
    private Map<Coordinate, Coordinate> hWalls = new HashMap<Coordinate, Coordinate>();
    private Map<Coordinate, Coordinate> vWalls = new HashMap<Coordinate, Coordinate>();
    private Set<Walls> walls = new HashSet<Walls>();
    //

    /**
     * Initializes your player module. In this method, be sure to set up your data structures and pre-populate them with
     * the starting board configuration. All state should be stored in your player class.
     * @param logger reference to the logger class
     * @param playerId the id of this player (1 up to 4, for a four-player game)
     * @param numWalls the number of walls this player has
     * @param playerHomes locations of other players (null coordinate means invalid player; 1-based indexing)
     */
    @Override
    public void init(Logger logger, int playerId, int numWalls, Map<Integer, Coordinate> playerHomes) {
        this.numWalls = numWalls;
        Coordinate coor;
        this.playerId = playerId;
        this.logger = logger;
        if (this.playerId == 1){
            coor = new Coordinate(8,4);
            this.playerHomes.put(playerId, coor);
        }else if (this.playerId == 2){
            coor = new Coordinate(0,4);
            this.playerHomes.put(playerId, coor);
        }else if (this.playerId == 3){
            coor = new Coordinate(4,0);
            this.playerHomes.put(playerId, coor);
        }else{
            coor = new Coordinate(4,8);
            this.playerHomes.put(playerId, coor);
        }
        this.playerWalls.put(playerId, this.numWalls);
        for (int i = 0; i < board.length; i++){
            for(int j = 0; j < board.length; j++){
                board[i][j] = new Node("C"/*new Coordinate(i, j)*/);
            }
        }
        //top left corner
        board[0][0].addNeighbor(board[0][1]);
        board[0][0].addNeighbor(board[1][0]);
        //top right corner
        board[0][8].addNeighbor(board[0][7]);
        board[0][8].addNeighbor(board[1][8]);
        //bottom left corner
        board[8][0].addNeighbor(board[8][1]);
        board[8][0].addNeighbor(board[7][0]);
        //bottom right corner
        board[8][8].addNeighbor(board[8][7]);
        board[8][8].addNeighbor(board[7][8]);
        for (int i = 0; i < board.length; i++){
            for(int j = 0; j < board.length; j++){
                if (!(i+1 > MAX_ROWS-1)){
                    board[i][j].addNeighbor(board[i+1][j]);
                }
                if (!(j+1 > MAX_COLUMNS-1)){
                    board[i][j].addNeighbor(board[i][j+1]);
                }
                if (!(i-1 < 0)){
                    board[i][j].addNeighbor(board[i-1][j]);
                }
                if (!(j-1 < 0)){
                    board[i][j].addNeighbor(board[i][j-1]);
                }
            }
        }

        //Horizontal Wall Possiblities
        /*
        for (int i = 0; i < MAX_ROWS-2; i++){
            for(int j = 0; j < MAX_COLUMNS-2; j++){
                Coordinate start = new Coordinate( i, j);
                Coordinate end = new Coordinate( i+2, j+2);
                hWalls.put(start, end);
            }
        }*/

        //Vertical Wall Possibilites
        /*
        for (int i = 0; i < MAX_ROWS; i++){
            for(int j = 0; j < MAX_COLUMNS; j++){
                Coordinate start = new Coordinate( j, i);
                Coordinate end = new Coordinate( j+2, i+2);
                vWalls.put(start, end);
            }
        }*/
    }

    /**
     * Notifies you that a move was just made. Use this function to update your board state accordingly. You may assume
     * that all moves are given to you in the order that they are made.
     * @param playerMove
     */
    @Override
    public void lastMove(PlayerMove playerMove) {
        if (playerMove.isMove() == true) {
            Coordinate newCoor = board[playerMove.getEndRow()][playerMove
                    .getEndCol()].getLocation();
            playerHomes.put(playerMove.getPlayerId(), newCoor);
            playerMoving = true;
        }
        else { //playerMove is false
            playerMoving = false;
            //int newWallVal = playerWalls.get(playerMove.getPlayerId())-1;
            playerWalls.put(playerMove.getPlayerId(), playerWalls.get(playerMove.getPlayerId())-1);
            Coordinate start = playerMove.getStart();
            Coordinate end = playerMove.getEnd();
            Coordinate tempStart;
            Coordinate tempEnd;
            Walls orignal = new Walls(start, end);
            walls.add(orignal);
            walls.add(orignal.bisect());
            for (int i = 0; i < orignal.surrounding().size(); i++){
                walls.add(orignal.surrounding().get(i));
            }
            //Horizontal
            if (start.getRow() == end.getRow()){
                /*don't need to address these cases
                if (start.getRow() == 9 && end.getRow() == 9){
                    board[start.getRow()][start.getCol()].removeNeighborQadir(null);
                    board[end.getRow()][end.getCol()].removeNeighborQadir(null);
                }
                else if (start.getCol() == 9){//start[4,9], en
                    board[start.getRow()][start.getCol()].removeNeighborQadir(null);
                    board[end.getRow()][end.getCol()].removeNeighborQadir(null);
                }
                else*/ if (end.getCol() == 9){//start = [4,7] , end = [4,9]
                    board[start.getRow()][start.getCol()].removeNeighborQadir(board[start.getRow() - 1][start.getCol()]);//[4,7] removes [3,7]
                    board[end.getRow()][end.getCol()-1].removeNeighborQadir(board[end.getRow() - 1][end.getCol() - 1]);//[4,8] removes [3,8]
                }else{//start = [4,4] end = [4,6]
                    board[start.getRow()][start.getCol()].removeNeighborQadir(board[start.getRow() - 1][start.getCol()]);//[4,4] removes [3,4]
                    board[end.getRow()][end.getCol()-1].removeNeighborQadir(board[end.getRow() - 1][end.getCol() - 1]);//[4,5] removes [3,5]
                }
            }
            //vertical
            else if (start.getCol() == end.getCol()){
                //Adding all the invalid orientations
                /*don't need to address these cases
                if (start.getCol() == 9 && end.getCol() == 9){
                    board[start.getRow()][start.getCol()].removeNeighborQadir(null);
                    board[end.getRow()][end.getCol()].removeNeighborQadir(null);
                }
                else if (start.getRow() == 9){
                    board[start.getRow()][start.getCol()].removeNeighborQadir(null);
                    board[end.getRow()][end.getCol()].removeNeighborQadir(null);
                }
                else*/ if (end.getRow() == 9){
                    board[start.getRow()][start.getCol()].removeNeighborQadir(board[start.getRow()][start.getCol() - 1]);//[7,8] removes [7,7]
                    board[end.getRow()-1][end.getCol()].removeNeighborQadir(board[end.getRow() - 1][end.getCol() - 1]);//[8,8] removes [8,7]
                }else{
                    board[start.getRow()][start.getCol()].removeNeighborQadir(board[start.getRow()][start.getCol() - 1]);//[4,4] removes [4,3]
                    board[end.getRow()-1][end.getCol()].removeNeighborQadir(board[end.getRow() - 1][end.getCol() - 1]);//[5,4] removes [5,3]
                }
            }
        }
    }

    @Override
    public void playerInvalidated(int i) {

    }

    @Override
    public PlayerMove move() {
        return null;
    }

    /**
     * Return the 1-based player ID of this player.
     * @return the 1-based player ID of this player.
     */
    @Override
    public int getID() {
        return playerId;
    }

    /**
     * Returns the subset of the four adjacent cells to which a piece could move due to lack of walls. The system calls
     * this function only to verify that a Player's implementation is correct. However it is likely also handy for most
     * strategy implementations.
     * @param coordinate the "current location"
     * @return a set of adjacent coordinates (up-down-left-right only) that are not blocked by walls
     */
    @Override
    public Set<Coordinate> getNeighbors(Coordinate coordinate) {
        Set<Coordinate> neighbors = new HashSet<Coordinate>();
        int xVal =coordinate.getRow();
        int yVal = coordinate.getCol();
        for (int i = 0; i < board[xVal][yVal].getNeighbors().size(); i++){
            neighbors.add(board[xVal][yVal].getNeighbors().get(i).getLocation());
        }
        return neighbors;
    }

    /**
     * Returns any valid shortest path between two coordinates, if one exists. The system calls this function only to
     * verify that your implementation is correct. You may also use it to test your code.
     * @param start the start coordinate
     * @param end the end coordinate
     * @return an ordered list of Coordinate objects representing a path. If no path exists, return an empty list.
     */
    @Override
    public List<Coordinate> getShortestPath(Coordinate start, Coordinate end){
        List<Coordinate> shortestPath = new ArrayList<Coordinate>();
        if (start.equals(end)){
            shortestPath.add(0, start);
            return shortestPath;
        }
        List<Node> list = searchBFS(start, end);
        for (int i = 0; i < list.size(); i ++){
            //shortestPath.add(list.get(i).getLocation());
        }
        return shortestPath;
    }


    /**
     * Get the remaining walls for your player.
     * @param i  1-based player ID number
     * @return
     */
    @Override
    public int getWallsRemaining(int i) {
        if(!(playerHomes.containsKey(i))) {
            if (i == 1) {
                playerWalls.put(i, this.numWalls);
            }else if (i == 2){
                playerWalls.put(i, this.numWalls);
            }else if (i == 3){
                playerWalls.put(i, this.numWalls);
            }else if (i == 4){
                playerWalls.put(i, this.numWalls);
            }
        }
        return playerWalls.get(i);
    }

    /**
     * Get the location of a given player.
     * @param i 1-based player ID number
     * @return the location of a given player
     */
    @Override
    public Coordinate getPlayerLocation(int i) {
        Coordinate coor;
        if (!playerHomes.containsKey(i)) {
            if (i == 2) {
                coor = new Coordinate(0, 4);
                this.playerHomes.put(i, coor);
            } else if (i == 3) {
                coor = new Coordinate(4, 0);
                this.playerHomes.put(i, coor);
            } else {
                coor = new Coordinate(4, 8);
                this.playerHomes.put(i, coor);
            }
        }
        return playerHomes.get(i);
    }

    /**
     * Get the location of every player. (1-based index)
     * @return a map representation of the location of every player.
     */
    @Override
    public Map<Integer, Coordinate> getPlayerLocations() {
        return playerHomes;
    }


    @Override
    public Set<PlayerMove> allPossibleMoves() {
        if (playerMoving){
            Set<PlayerMove> allPieceMoves = getAllPieceMoves();
            return allPieceMoves;
        }
        Set<PlayerMove> allWallMoves = getAllWallMoves();
        return allWallMoves;

    }

    private Set <PlayerMove> getAllPieceMoves(){
        Set<PlayerMove> pieceMoves = new HashSet<>();
        Set<Coordinate> possibleCoordinates = new HashSet<>();
        Coordinate locationOfPlayer = getPlayerLocation(getID());
        Set<Coordinate >occupiedCoordinates = new HashSet<Coordinate>();//Set of coordinates that are occupied by the
        //players
        int xVal = locationOfPlayer.getRow();
        int yVal = locationOfPlayer.getCol();
        List<Node> neighborList = board[xVal][yVal].getNeighbors();
        Node locationNode = board[xVal][yVal];
        Node temp;
        Node temp2;
        Coordinate tempCoor;

        for(int i : playerHomes.keySet()){//Gets the locations of every player
            occupiedCoordinates.add(playerHomes.get(i));
        }

        if(!(xVal-1 < 0) && neighborList.contains(board[xVal-1][yVal])){//Location in front of the player
            temp = board[xVal-1][yVal];
            tempCoor = temp.getLocation();
            if(!occupiedCoordinates.contains(tempCoor)){//This means that the location in front is not occupied
                // nor blocked by a wall
                possibleCoordinates.add(tempCoor);
            }
            else if (occupiedCoordinates.contains(tempCoor)){//If an opponent is in front of the player [CHANGE TO ELSE LATER]
                temp2 = board[tempCoor.getRow()-1][yVal];//The space behind the opponent in which a player can jump to
                if(temp.getNeighbors().contains(temp2) &&
                        !occupiedCoordinates.contains(temp2.getLocation())){
                    //check to see if the location behind the opponent is blocked by a wall
                    // or open
                    possibleCoordinates.add(temp2.getLocation());
                }
                //L jump cases
                else{ //[commented out cuz i'm not sure if L jumps and player jumping can be valid at the same time]
                    if (temp.getNeighbors().contains(board[xVal-1][yVal-1])){//means the location is not blocked by a wall
                        possibleCoordinates.add(board[xVal-1][yVal-1].getLocation());
                    }
                    if(temp.getNeighbors().contains(board[xVal-1][yVal+1])){//means the location is not blocked by a wall
                        possibleCoordinates.add(board[xVal-1][yVal+1].getLocation());
                    }
                }
            }
        }
        if(!(yVal+1 > 8) && neighborList.contains(board[xVal][yVal+1])){//location to the right of the player
            temp = board[xVal][yVal+1];
            tempCoor = temp.getLocation();
            if(!occupiedCoordinates.contains(tempCoor)){//This means that the location to the right
                // is not occupied nor blocked by a wall
                possibleCoordinates.add(tempCoor);
            }
            else {//an opponent is to the right of the player
                temp2 = board[xVal][tempCoor.getCol() + 1];
                if (temp.getNeighbors().contains(temp2) && !occupiedCoordinates.contains(temp2.getLocation())) {
                    possibleCoordinates.add(temp2.getLocation());
                }
                //L jump cases
                else{
                    if(temp.getNeighbors().contains(board[xVal-1][yVal+1])){
                        possibleCoordinates.add(board[xVal-1][yVal+1].getLocation());
                    }
                    if(temp.getNeighbors().contains(board[xVal+1][yVal+1])){
                        possibleCoordinates.add(board[xVal+1][yVal+1].getLocation());
                    }
                }
            }
        }
        if(!(xVal+1 > 8) &&neighborList.contains(board[xVal+1][yVal])){//location behind the player
            temp = board[xVal+1][yVal];
            tempCoor = temp.getLocation();
            if(!occupiedCoordinates.contains(tempCoor)){//This means that the location is not occupied nor blocked by a wall
                possibleCoordinates.add(tempCoor);
            }
            else{//an opponent is behind the player
                temp2 = board[tempCoor.getRow()+1][yVal];
                if(temp.getNeighbors().contains(temp2) && !occupiedCoordinates.contains(temp2.getLocation())){
                    possibleCoordinates.add(temp2.getLocation());
                }
                else{
                    if(temp.getNeighbors().contains(board[xVal+1][yVal+1])){
                        possibleCoordinates.add(board[xVal+1][yVal+1].getLocation());
                    }
                    if(temp.getNeighbors().contains(board[xVal+1][yVal-1])){
                        possibleCoordinates.add(board[xVal+1][yVal-1].getLocation());
                    }
                }

            }
        }
        if(!(yVal-1 < 0) && neighborList.contains(board[xVal][yVal-1])){//location to the left of the player
            temp = board[xVal][yVal-1];
            tempCoor = temp.getLocation();
            if(!occupiedCoordinates.contains(tempCoor)){//This means that the location is not occupied nor blocked by a wall
                possibleCoordinates.add(tempCoor);
            }
            else{
                temp2 = board[xVal][tempCoor.getCol()-1];
                if(temp.getNeighbors().contains(temp2) && !occupiedCoordinates.contains(temp2.getLocation())){
                    possibleCoordinates.add(temp2.getLocation());
                }
                else{
                    if(temp.getNeighbors().contains(board[xVal-1][yVal-1])){
                        possibleCoordinates.add(board[xVal-1][yVal-1].getLocation());
                    }
                    if(temp.getNeighbors().contains(board[xVal+1][yVal-1])){
                        possibleCoordinates.add(board[xVal+1][yVal-1].getLocation());
                    }
                }

            }
        }
        for (Coordinate coor : possibleCoordinates){
            pieceMoves.add(new PlayerMove(getID(), true, locationOfPlayer, coor));
        }
        occupiedCoordinates.clear();
        return pieceMoves;
    }
    private Set<PlayerMove> getAllWallMoves(){
        Set<PlayerMove> wallMoves = new HashSet<PlayerMove>();
        Coordinate tmpStart;
        Coordinate tmpEnd;
        /*implementation works too well, Deever said to use the search algorithms here
        "Looks like you're ready for adding in the part of the wall analysis where you make
        sure that adding a certain wall doesn't block any of the players from reaching the goal.
        Keep in mind you'll need to check this for every player. Also, the wall is ok as long as there is a single goal
        square that is still reachable. You'll want to call on your searching algorithms again here. Doesn't have to be
        bfs, since shortest path doesn't matter. You just want to know if any of the goal squares are reachable."
         */

        Walls tmpWall;
        for(int i = 0; i <= MAX_ROWS; i++){
            for(int j = 0; j <= MAX_COLUMNS; j++){
                tmpStart = new Coordinate(i, j);
                if(tmpStart.getRow() <= 7 && tmpStart.getCol() <= 7){
                    //Horizontal
                    tmpEnd = new Coordinate(i , j+2);
                    if(tmpStart.getRow() == tmpEnd.getRow() && tmpEnd.getRow() != 0){
                        if(tmpEnd.getCol() - tmpStart.getCol() == 2){
                            tmpWall = new Walls(tmpStart, tmpEnd);
                            if(!walls.contains(tmpWall)){
                                wallMoves.add(new PlayerMove(getID(),false, tmpStart, tmpEnd));
                            }
                        }
                    }
                    tmpEnd = new Coordinate(i+2, j);
                    //Vertical
                    if(tmpStart.getCol() == tmpEnd.getCol() && tmpEnd.getCol() != 0){//tmpStart.getCol() == tmpEnd.getCol()
                        if(tmpEnd.getRow() - tmpStart.getRow() == 2){
                            tmpWall = new Walls(tmpStart, tmpEnd);
                            if(!walls.contains(tmpWall)){
                                wallMoves.add(new PlayerMove(getID(),false, tmpStart, tmpEnd));
                            }
                        }

                    }
                }
                if(tmpStart.getRow() == 8){
                    tmpEnd = new Coordinate(8, tmpStart.getCol()+2);
                    if(tmpEnd.getCol() > 9){
                        continue;
                    }
                    tmpWall = new Walls(tmpStart, tmpEnd);
                    if(!walls.contains(tmpWall)){
                        wallMoves.add(new PlayerMove(getID(),false, tmpStart, tmpEnd));
                    }
                }
                else if(tmpStart.getCol() == 8){
                    tmpEnd = new Coordinate(tmpStart.getRow()+2, 8);
                    if(tmpEnd.getRow() > 9){
                        continue;
                    }
                    tmpWall = new Walls(tmpStart, tmpEnd);
                    if(!walls.contains(tmpWall)){
                        wallMoves.add(new PlayerMove(getID(),false, tmpStart, tmpEnd));
                    }
                }
            }
        }
        return wallMoves;
    }
    /**
     * Implementation of BFS to work with the coordinates of the board
     * @param start coordinate to start at
     * @param finish coordinate to end at
     * @return path of nodes, if no route is found, return list is empty
     */
    private List<Node> searchBFS(Coordinate start, Coordinate finish) {
        // assumes input check occurs previously
        Node startNode, finishNode;
        startNode = board[start.getRow()][start.getCol()];
        finishNode = board[finish.getRow()][finish.getCol()];

        // prime the dispenser (queue) with the starting node
        List<Node> dispenser = new LinkedList<Node>();
        dispenser.add(startNode);

        // construct the predecessors data structure
        Map<Node, Node> predecessors = new HashMap<Node,Node>();
        // put the starting node in, and just assign itself as predecessor
        predecessors.put(startNode, startNode);

        // loop until either the finish node is found, or the
        // dispenser is empty (no path)
        while (!dispenser.isEmpty()) {
            Node current = dispenser.remove(0);
            if (current == finishNode) {
                break;
            }
            // loop over all neighbors of current
            for (Node nbr : current.getNeighbors()) {
                // process unvisited neighbors
                if(!predecessors.containsKey(nbr)) {
                    predecessors.put(nbr, current);
                    dispenser.add(nbr);
                }
            }
        }

        return constructPath(predecessors, startNode, finishNode);
    }
    /**
     * Method to return a path from the starting to finishing node.
     *
     * @param predecessors Map used to reconstruct the path
     * @param startNode starting node
     * @param finishNode finishing node
     * @return a list containing the sequence of nodes comprising the path.
     * Empty if no path exists.
     */
    private List<Node> constructPath(Map<Node,Node> predecessors,
                                     Node startNode, Node finishNode) {
        // use predecessors to work backwards from finish to start,
        // all the while dumping everything into a linked list
        List<Node> path = new LinkedList<Node>();

        if(predecessors.containsKey(finishNode)) {
            Node currNode = finishNode;
            while (currNode != startNode) {
                path.add(0, currNode);
                currNode = predecessors.get(currNode);
            }
            path.add(0, startNode);
        }

        return path;
    }
}
