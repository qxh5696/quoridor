package Players.Gogeta;

/*
 * Node.java
 *
 * Representation of a graph node.
 *
 */

import Interface.Coordinate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Class representing a node in a graph.
 * 
 * @author atd Aaron T Deever
 * @author dxr5716 Daniel Roach
 */

public class Node {

	/*
	 *  Name associated with this node.
	 */
	private String name;

	/*
	 * Neighbors of this node are stored as a list (adjacency list).
	 */
	private List<Node> neighbors;

    private Coordinate location;
	/**
	 * Constructor.  Initialized with an empty list of neighbors.
	 * 
	 * @param name string representing the name associated with the node.
	 */
	public Node(String name) { 
		this.name = name;
		this.neighbors = new ArrayList<Node>();
        this.location = null;
	}

    public Node(Coordinate coordinate) {
        this.location = coordinate;
        this.neighbors = new LinkedList<Node>();
    }

    public Node(Node node){
        this.location = new Coordinate(node.getLocation().getRow(), node.getLocation().getCol());
    }
    public Node(String name, Coordinate coor) {
        this.name = name;
        this.location = coor;
    }

    public Coordinate getLocation(){
        return this.location;
    }

	/**
	 * Get the String name associated with this object.
	 * 
	 * @return name.
	 */
	public String getName() { 
		return name;
	}

    public void removeNeighborQadir(Node node){
        this.neighbors.remove(node);
        node.neighbors.remove(this);
    }

	/**
	 * Add a neighbor to this node.  Checks if already present, and does not
	 * duplicate in this case.
	 * 
	 * @param n: node to add as neighbor.
	 */
	public void addNeighbor(Node n) { 
		if(!neighbors.contains(n)) { 
			this.neighbors.add(n);
            n.neighbors.add(this);
		}
	}

	/**
	 * Method to return the adjacency list for this node containing all 
	 * of its neighbors.
	 * 
	 * @return the list of neighbors of the given node
	 */
	public List<Node> getNeighbors() { 
		return new ArrayList<Node>(neighbors);
	}

	/**
	 * Method to generate a string associated with the node, including the 
	 * name of the node followed by the names of its neighbors.  Overrides
	 * Object toString method.
	 * 
	 * @return string associated with the node.
	 */

	public String toStringDan() {
		String result;
		result = name + ":  ";

		for(Node nbr : neighbors) { 
			result = result + nbr.getName() + ", ";
		}
		// remove last comma and space, or just spaces in the
		// case of no neighbors
		return (result.substring(0, result.length()-2));
	}

    public String toStringQadir(){
        String result;
        result = location.toString() + "Neighbors: (";

        for (Node nbr: this.neighbors){
            result += nbr.getLocation().toString() + ",";
        }
        //get rid of commas
        result = result.substring(0, result.length()-1);
        result += ")";
        return result;
    }
	/**
	 *  Two Nodes are equal if they have the same name.
	 *  @param other The other object to check equality with
	 *  @return true if equal; false otherwise
	 */

	public boolean equalsDan(Object other) {
		boolean result = false;
		if (other instanceof Node) {
			Node n = (Node) other;
			result = this.name.equals(n.name);
		}
		return result;
	}


    public boolean equals(Object other){
        boolean result = false;
        if (other instanceof Node){
            Node n = (Node) other;
            if(this.getLocation().equals(n.getLocation())){
                result = true;
            }
        }
        return result;
    }

	/**
	 * The hash code of a Node is just the hash code of the name,
	 * since no two nodes can have the same name.
	 */
	@Override
    public int hashCode() {
        return this.location.hashCode();
	}

    /**
     * Remove one of the neighboring nodes
     * @param neighbor the node to remove
     */
    public void removeNeighborDan(Node neighbor) {
        neighbors.remove(neighbor);
    }
}
